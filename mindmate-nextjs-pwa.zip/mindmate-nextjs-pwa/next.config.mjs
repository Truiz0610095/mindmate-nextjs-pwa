/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // App Router is enabled by default in Next 14 when using /app
  images: { unoptimized: true }
};
export default nextConfig;
