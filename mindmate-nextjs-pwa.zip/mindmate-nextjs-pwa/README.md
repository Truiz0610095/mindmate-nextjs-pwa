# MindMate – Piloto Next.js

Piloto mínimo de MindMate listo para desplegar en Vercel y usar como PWA (agregar a pantalla de inicio).

## Scripts
- dev: `npm run dev`
- build: `npm run build`
- start: `npm start`

## Notas
- No requiere base de datos ni backend.
- Incluye manifest para instalación como app.
