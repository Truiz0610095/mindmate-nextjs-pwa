export const metadata = {
  title: 'MindMate',
  description: 'Tu compañero emocional impulsado por IA'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <head>
        <link rel="manifest" href="/manifest.webmanifest" />
        <meta name="theme-color" content="#0ea5e9" />
        <link rel="icon" href="/icon-192.png" />
      </head>
      <body style={{ fontFamily: 'system-ui, Arial, sans-serif', background:'#f8fafc', color:'#0f172a', margin:0 }}>
        <div style={{ maxWidth: 480, margin: '0 auto', padding: 16 }}>{children}</div>
      </body>
    </html>
  );
}
